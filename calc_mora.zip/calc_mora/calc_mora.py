import re
import string
import unicodedata

import jaconv
import MeCab

# Main


def segment_by_mora_rule(text):
    return moraWakachi(getPronunciation(text))


def calc_mora(filename):
    sum_of_mora = 0
    for line in open(filename, 'r'):
        mora_list = segment_by_mora_rule(line)
        sum_of_mora += len(mora_list)

    return sum_of_mora

# カナ変換


def format_text(text):
    text = unicodedata.normalize("NFKC", text)  # 全角記号をざっくり半角へ置換（でも不完全）

    # 記号を消し去るための魔法のテーブル作成
    table = str.maketrans("", "", string.punctuation + "「」、。・")
    text = text.translate(table)

    return text


def getPronunciation(text):
    m = MeCab.Tagger()  # 形態素解析用objectの宣言
    m_result = m.parse(text).splitlines()  # mecabの解析結果の取得
    m_result = m_result[:-1]  # 最後の1行は不要な行なので除く

    pro = ''  # 発音文字列全体を格納する変数
    for v in m_result:
        if '\t' not in v:
            continue
        surface = v.split('\t')[0]  # 表層形
        p = v.split('\t')[1].split(',')[-1]  # 発音を取得したいとき
        # p = v.split('\t')[1].split(',')[-2] #ルビを取得したいとき
        # 発音が取得できていないときsurfaceで代用
        if p == '*':
            p = surface
        pro += p

    pro = jaconv.hira2kata(pro)  # ひらがなをカタカナに変換
    pro = format_text(pro)  # 余計な記号を削除

    return pro


# モーラ分ち


c1 = '[ウクスツヌフムユルグズヅブプヴ][ァィェォ]'  # ウ段＋「ァ/ィ/ェ/ォ」
c2 = '[イキシシニヒミリギジヂビピ][ャュェョ]'  # イ段（「イ」を除く）＋「ャ/ュ/ェ/ョ」
c3 = '[テデ][ィュ]'  # 「テ/デ」＋「ャ/ィ/ュ/ョ」
c4 = '[ァ-ヴー]'  # カタカナ１文字（長音含む）

cond = '('+c1+'|'+c2+'|'+c3+'|'+c4+')'
re_mora = re.compile(cond)


def moraWakachi(kana_text):
    return re_mora.findall(kana_text)

##########################################
