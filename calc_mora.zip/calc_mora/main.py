import csv
import glob
import os

import calc_mora

BASEDIR = os.path.dirname(os.path.abspath(__file__))

OUT_DIR = BASEDIR + '/result'
FRAUD_MORA_COUNT_FILE = 'fraud_mora_count.csv'
NORMAL_MORA_COUNT_FILE = 'normal_mora_count.csv'

FRAUD_DIR = BASEDIR + '/data/fraud_conversation/*'
NORMAL_DIR = BASEDIR + '/data/normal_conversation/*'


def calc_mora_all_in_dir(dirname):
    file_list = glob.glob(dirname)

    mora_list = []
    for f in file_list:
        print(f)
        mora = calc_mora.calc_mora(f)
        mora_list.append([f.split('/')[-1], mora])

    return mora_list


def main():
    with open(OUT_DIR + '/' + NORMAL_MORA_COUNT_FILE, 'w') as f:
        writer = csv.writer(f)
        writer.writerows(calc_mora_all_in_dir(NORMAL_DIR))

    with open(OUT_DIR + '/' + FRAUD_MORA_COUNT_FILE, 'w') as f:
        writer = csv.writer(f)
        writer.writerows(calc_mora_all_in_dir(FRAUD_DIR))


if __name__ == '__main__':
    main()
